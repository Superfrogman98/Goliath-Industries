{
	type = "base"
	retrogen = false
	sprinkleMix = false
	veinSize = 10
	biomeRules = {
		combination = "or"
		strict = false
	}
	blocks = {
	}
	dimensionRules = {
		combination = "or"
	}
	heightRule = {
		maxHeight = 64
		minHeight = 0
		variation = "linear"
	}
	proximityRules = {
	}
	spawnBlock = {
		{
			block = "minecraft:stone"
		}
	}
	veinFrequency = {
		chunkGenChance = 1
		veinsPerChunk = 8
	}
}
