{
	type = "global"
	cave_size = 1.0
	density = 1.2
	dungeons = 1.0
	gen_strongholds = true
	large_cave_chance = 25.0
	large_cave_size = 1.7
	large_cave_variance = 6.0
	lava_caves = true
	max_y = 256
	min_y = 0
	mineshafts = 1.0
	ravines = 1.0
	vscale = 1.0
	water_caves = false
}
